<?php

class MySQLDBException extends \Exception {}

?>