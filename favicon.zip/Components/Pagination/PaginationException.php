<?php

class PaginationException extends \Exception {}

?>