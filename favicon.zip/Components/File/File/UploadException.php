<?php

class UploadException extends \Exception {}

?>