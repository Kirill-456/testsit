<?php

class ImageException extends \Exception {}

?>